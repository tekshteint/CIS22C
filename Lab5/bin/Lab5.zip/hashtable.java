/*
 * hash scheme: (m * w + n * f) % size
 * 		size = 29
 * 		m = 2
 * 		n = 3
 * 		w = whole
 * 		f = fraction
 * collisions should use quadratic probing DONE
 * load data into hash table and print number of data items loaded, load factor, and number of collisions
 * search for object and the print index, otherwise print invalid data DONE
 */
import java.util.ArrayList;
import java.lang.Math.*;
public class hashtable<t> {
	
    private hash<Currency>[] hashtables;
    private int collisions = 0;
    private int m = 2;
    private int n = 3;
    private int size;
    private double load;
    private int count;
    
    public hashtable() {
    	
    }
    public hashtable(int size) {
        hashtables = (hash<Currency>[]) new hash[size];
        for(int i = 0; i < size; ++i) {
            hashtables[i] = new hash();
        	hashtables[i].setIndex(i);
        }
        this.size = size;
    }
    
    public void insert(Currency dataval) {
    	int mNew = m;
    	int nNew = n;
    	int bucketsProbed = 0;
        int datalocation = (mNew * dataval.getWhole() + (nNew * nNew) * dataval.getFraction()) % size;
        
        while(bucketsProbed < size) {
        	if (hashtables[datalocation].getData() == null) {
        		hashtables[datalocation].setData(dataval);
        		setLoad();
        		count++;
        		break;
        	}
        	mNew++;
        	nNew++;
            datalocation = (mNew * dataval.getWhole() + (nNew * nNew) * dataval.getFraction()) % size;
            collisions++;
            bucketsProbed++;
        }
    }
    
    public Currency search(Currency dataval) {
    	int mNew = m;
    	int nNew = n;
    	int bucketsProbed = 0;
        int datalocation = (mNew * dataval.getWhole() + (nNew * nNew) * dataval.getFraction()) % size;        
        
        while((hashtables[datalocation] != null) && (bucketsProbed < size)) {
        	if (hashtables[datalocation].getData().getWhole() == dataval.getWhole() && 
        			hashtables[datalocation].getData().getFraction() == dataval.getFraction()) {
        		return dataval;
        	}
        	mNew++;
        	nNew++;
        	bucketsProbed++;
        	datalocation = (mNew * dataval.getWhole() + (nNew * nNew) * dataval.getFraction()) % size;  
    	}
        return null;
    }
    
    public void setLoad() {
    	int count = 0;
    	for (int i = 0; i < size; i++) {
    		if (hashtables[i].getData() != null)
    			count++;
    	}
    	this.load = (double)count / (double)size;
    }
    
    public double getLoad() {
    	return this.load;
    }
    
    public int getCollisions() {
    	return this.collisions;
    }
    
    public int getCount() {
    	return this.count;
    }
    
    @Override
    public String toString() {
    	String ret = "";
    	ret += "Load Factor: " + getLoad() + "\n\n";
    	ret += "Collisions: " + getCollisions() + "\n\n";
    	ret += "Number of items: " + getCount() + "\n\n";
    	for (int i = 0; i < size; i++) {
    		if (hashtables[i].getData() != null) {
    			ret += ("Index: " + i + "\nValue: " + hashtables[i].getData().toString() + "\n\n");
    		} else {
    			ret += ("Index: " + i + "\nValue: null\n\n");
    		}
    	}
    	return ret;
    }
    
}
